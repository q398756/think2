/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : pictureapp

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2018-05-29 18:29:12
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `picturetype`
-- ----------------------------
DROP TABLE IF EXISTS `picturetype`;
CREATE TABLE `picturetype` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Heat` int(11) DEFAULT '0',
  `Num` int(11) DEFAULT '0',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picturetype
-- ----------------------------
INSERT INTO `picturetype` VALUES ('1001', '自然', '0', '2');
INSERT INTO `picturetype` VALUES ('1002', '人物', '3', '9');
INSERT INTO `picturetype` VALUES ('1003', '动漫', '0', '2');
INSERT INTO `picturetype` VALUES ('1004', '体育', '0', '0');
INSERT INTO `picturetype` VALUES ('1005', '人文', '23', '29');
INSERT INTO `picturetype` VALUES ('1006', '科技', '1', '6');
INSERT INTO `picturetype` VALUES ('1007', '故事', '0', '2');
