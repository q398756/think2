/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : pictureapp

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2018-05-29 18:28:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `author`
-- ----------------------------
DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `Id` int(11) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Cellphone` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of author
-- ----------------------------
INSERT INTO `author` VALUES ('1001', 'Tommy', null);
INSERT INTO `author` VALUES ('1002', 'Jimmy', '1502597812');
INSERT INTO `author` VALUES ('1003', 'Demo', null);
INSERT INTO `author` VALUES ('1004', 'Hins', null);
INSERT INTO `author` VALUES ('1005', 'E.Xi', '1364569121');
