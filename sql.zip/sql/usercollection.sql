/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : pictureapp

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2018-05-29 18:30:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `usercollection`
-- ----------------------------
DROP TABLE IF EXISTS `usercollection`;
CREATE TABLE `usercollection` (
  `userId` int(11) NOT NULL,
  `picId` int(11) NOT NULL,
  PRIMARY KEY (`userId`,`picId`),
  KEY `userID` (`userId`) USING BTREE,
  KEY `picID` (`picId`) USING BTREE,
  CONSTRAINT `pID` FOREIGN KEY (`picId`) REFERENCES `picture` (`Id`),
  CONSTRAINT `uID` FOREIGN KEY (`userId`) REFERENCES `user` (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of usercollection
-- ----------------------------
INSERT INTO `usercollection` VALUES ('1001', '1006');
INSERT INTO `usercollection` VALUES ('1001', '1017');
INSERT INTO `usercollection` VALUES ('1001', '1027');
INSERT INTO `usercollection` VALUES ('1001', '1029');
INSERT INTO `usercollection` VALUES ('1001', '1030');
INSERT INTO `usercollection` VALUES ('1001', '1047');
INSERT INTO `usercollection` VALUES ('1001', '1049');
INSERT INTO `usercollection` VALUES ('1002', '1024');
INSERT INTO `usercollection` VALUES ('1002', '1025');
INSERT INTO `usercollection` VALUES ('1002', '1026');
INSERT INTO `usercollection` VALUES ('1002', '1027');
INSERT INTO `usercollection` VALUES ('1002', '1028');
INSERT INTO `usercollection` VALUES ('1002', '1029');
INSERT INTO `usercollection` VALUES ('1002', '1030');
INSERT INTO `usercollection` VALUES ('1002', '1031');
INSERT INTO `usercollection` VALUES ('1002', '1032');
INSERT INTO `usercollection` VALUES ('1002', '1033');
INSERT INTO `usercollection` VALUES ('1002', '1034');
INSERT INTO `usercollection` VALUES ('1002', '1035');
INSERT INTO `usercollection` VALUES ('1002', '1036');
INSERT INTO `usercollection` VALUES ('1002', '1037');
INSERT INTO `usercollection` VALUES ('1002', '1041');
INSERT INTO `usercollection` VALUES ('1006', '1026');
INSERT INTO `usercollection` VALUES ('1006', '1030');
INSERT INTO `usercollection` VALUES ('1009', '1026');
INSERT INTO `usercollection` VALUES ('1009', '1027');
INSERT INTO `usercollection` VALUES ('1009', '1030');
