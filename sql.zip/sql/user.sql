/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : pictureapp

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2018-05-29 18:30:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `Nickname` varchar(20) NOT NULL,
  `Sex` char(2) DEFAULT NULL,
  `Cellphone` bigint(11) DEFAULT NULL,
  `Password` varchar(20) NOT NULL,
  `PictureNum` int(2) unsigned NOT NULL DEFAULT '0' COMMENT '已收藏图片数',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1001', '刘华', 'M', '15019889898', '123456.a', '7');
INSERT INTO `user` VALUES ('1002', 'Darling', 'F', '15019889101', 'asdfghjkl', '15');
INSERT INTO `user` VALUES ('1003', 'Dear.Jim', 'M', '15012111312', 'asdfghjkl', '0');
INSERT INTO `user` VALUES ('1004', '15012312312', 'F', '15012312312', '123456.a', '0');
INSERT INTO `user` VALUES ('1005', '0504', 'M', '15019880504', '123456.a', '0');
INSERT INTO `user` VALUES ('1006', '0507', 'F', '15020180507', '123456.a', '2');
INSERT INTO `user` VALUES ('1007', '小明', 'F', '15019880518', '123456.a', '0');
INSERT INTO `user` VALUES ('1008', '小强', 'F', '15019880517', '123456.a', '0');
INSERT INTO `user` VALUES ('1009', '毕业设计', 'F', '15019880522', '123456.a', '3');
