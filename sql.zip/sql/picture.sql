/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50721
Source Host           : localhost:3306
Source Database       : pictureapp

Target Server Type    : MYSQL
Target Server Version : 50721
File Encoding         : 65001

Date: 2018-05-29 18:28:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `picture`
-- ----------------------------
DROP TABLE IF EXISTS `picture`;
CREATE TABLE `picture` (
  `Id` int(11) NOT NULL,
  `Author` int(11) DEFAULT NULL,
  `UploadId` int(11) DEFAULT NULL,
  `Desc` text NOT NULL,
  `TypeId` int(11) NOT NULL,
  `Address` text NOT NULL,
  `Heat` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`Id`),
  KEY `upld` (`UploadId`) USING BTREE,
  KEY `Type` (`TypeId`) USING BTREE,
  KEY `authorF` (`Author`) USING BTREE,
  CONSTRAINT `author` FOREIGN KEY (`Author`) REFERENCES `author` (`Id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `type` FOREIGN KEY (`TypeId`) REFERENCES `picturetype` (`Id`),
  CONSTRAINT `uploadid` FOREIGN KEY (`UploadId`) REFERENCES `user` (`Id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of picture
-- ----------------------------
INSERT INTO `picture` VALUES ('1001', '1001', null, '1001的描述', '1001', '1-1.jpg', '0');
INSERT INTO `picture` VALUES ('1002', null, null, '1002的DESC', '1003', '1-2.jpg', '0');
INSERT INTO `picture` VALUES ('1003', '1002', null, '1003没有描述', '1003', '1-3.jpg', '0');
INSERT INTO `picture` VALUES ('1004', '1003', '1002', '1004的缩写是大写的', '1001', '1-4.jpg', '0');
INSERT INTO `picture` VALUES ('1005', '1005', null, '1005是金黄色的', '1007', '1-5.jpg', '0');
INSERT INTO `picture` VALUES ('1006', null, null, 'car', '1006', '2-2.jpg', '1');
INSERT INTO `picture` VALUES ('1007', null, null, 'car2', '1006', '2-3.jpg', '0');
INSERT INTO `picture` VALUES ('1008', null, null, 'car3', '1006', '2-4.jpg', '0');
INSERT INTO `picture` VALUES ('1009', null, null, 'car4', '1006', '2-5.jpg', '0');
INSERT INTO `picture` VALUES ('1010', null, null, 'car5', '1006', '2-6.jpg', '0');
INSERT INTO `picture` VALUES ('1011', null, null, 'single', '1007', '3-1.jpg', '0');
INSERT INTO `picture` VALUES ('1012', '1001', null, 'apple', '1006', '3-2.jpg', '0');
INSERT INTO `picture` VALUES ('1013', null, null, '记录了于2012年10月18日，两名叙利亚反叛军士兵占着狙击点，周边的墙上布满了弹孔，光从外直射。', '1005', '117-673x448.jpg', '0');
INSERT INTO `picture` VALUES ('1014', null, null, '数次尝试自杀 27岁的美国驻伊拉克士兵布莱恩·斯哥特·奥斯特罗姆（Brian Scott Ostrom）在经过4年的海外战斗生涯后，带着严重的伤后应激障碍症退役回到祖国。作为第二侦察营的士兵，他曾两次被派往伊拉克，也就是在第二次服役伊拉克战争中，患上了应激障碍症。', '1002', '34-673x446.jpg', '0');
INSERT INTO `picture` VALUES ('1015', null, null, '《洛杉矶时报》的芭芭拉-戴维森将镜头对准洛杉矶帮会暴力冲突中的无辜受害者，并凭借这组照片获2011年普利策特写新闻摄影奖。', '1005', '44-673x447.jpg', '0');
INSERT INTO `picture` VALUES ('1016', null, null, '这种在科恩兄弟的电影中才得以一见的血腥场景，在洛杉矶黑帮势力盛行的地区并不少见，也是芭芭拉每每用镜头捕捉和记录的故事。过去两年中，这位美国女记者以她一贯对社会问题的关注和一双懂得创作的眼睛，近距离拍摄了一组黑帮冲突受害者的众生相。', '1005', '54-673x460.jpg', '0');
INSERT INTO `picture` VALUES ('1017', null, null, '记录了一名美国普通年轻人从应征入伍到成为一名正式军人的完整过程：应征时的犹豫，分别时的依恋，第一次想家，第一次受伤，第一次执行任务，订婚，前赴伊拉克，纹身，领结婚证…', '1002', '64-673x448.jpg', '1');
INSERT INTO `picture` VALUES ('1018', null, null, '记录了一名美国普通年轻人从应征入伍到成为一名正式军人的完整过程：应征时的犹豫，分别时的依恋，第一次想家，第一次受伤，第一次执行任务，订婚，前赴伊拉克，纹身，领结婚证…', '1002', '74-673x446.jpg', '0');
INSERT INTO `picture` VALUES ('1019', null, null, '《迈阿密先驱报》的摄影记者帕特里克-法瑞尔获得了2009年普利策突发新闻摄影奖。这些图片报道了艾克飓风和其他飓风给海地造成的人道灾难。评委们对获奖者的获奖评价是“对绝望的事情的刻画具有煽动性并且十分镇静沉着的图片”。', '1005', '84-673x389.jpg', '0');
INSERT INTO `picture` VALUES ('1020', null, null, 'Ike飓风登陆当晚，Patrick Farrell便身处海地灾害现场，那已经是一个月中第四场袭击海地的风暴，洪水导致超过800人死亡，至少100万人无家可归。', '1005', '94-673x469.jpg', '0');
INSERT INTO `picture` VALUES ('1021', null, null, '一名日本摄影记者在报道缅甸暴动时被打死的照片获得突发新闻摄影奖。', '1005', '104-673x346.jpg', '0');
INSERT INTO `picture` VALUES ('1022', null, null, '2005到2006年间，蕾妮用了近一年的时间，记录下单身母亲辛迪（Cyndie）是如何用自己的爱和耐心引导着儿子面对死亡。故事中的母亲辛迪，曾经是家庭暴力的受害者。作为一名单身母亲，辛迪在生活中表现出了常人所没有的坚强，她靠自己的双手养活了包括德雷克（Derek）在内的五个孩子，辛迪的小儿子德雷克被查出患有成神经细胞瘤这种罕见的癌症。为了给儿子治疗，辛迪放弃了原本发廊和灯具店的生意，全心全意陪伴在儿子身边，直到生命的最后一刻。\r\n', '1002', '118-673x464.jpg', '0');
INSERT INTO `picture` VALUES ('1023', null, null, '2005到2006年间，蕾妮用了近一年的时间，记录下单身母亲辛迪（Cyndie）是如何用自己的爱和耐心引导着儿子面对死亡。故事中的母亲辛迪，曾经是家庭暴力的受害者。作为一名单身母亲，辛迪在生活中表现出了常人所没有的坚强，她靠自己的双手养活了包括德雷克（Derek）在内的五个孩子，辛迪的小儿子德雷克被查出患有成神经细胞瘤这种罕见的癌症。为了给儿子治疗，辛迪放弃了原本发廊和灯具店的生意，全心全意陪伴在儿子身边，直到生命的最后一刻。\r\n', '1002', '124-673x847.jpg', '0');
INSERT INTO `picture` VALUES ('1024', null, null, '《落基山新闻》(Rocky Mountain News)吉姆·希勒拍摄的《最后的葬礼》获得本年度普利策特写新闻摄影奖。图片故事的内容是：在通知海军陆战队凯西少尉的妻子有关凯西少尉在伊拉克阵亡的消息后，海军陆战队贝克少校准备对凯西少尉的遗体进行最后的检查。贝克少校原以为自己会被派往伊拉克或阿富汗战场，但他却所领受的任务是他从未想像过的：为他牺牲的战友们安排葬礼。', '1005', '133-673x444.jpg', '1');
INSERT INTO `picture` VALUES ('1025', null, null, '《落基山新闻》(Rocky Mountain News)吉姆·希勒拍摄的《最后的葬礼》获得本年度普利策特写新闻摄影奖。图片故事的内容是：在通知海军陆战队凯西少尉的妻子有关凯西少尉在伊拉克阵亡的消息后，海军陆战队贝克少校准备对凯西少尉的遗体进行最后的检查。贝克少校原以为自己会被派往伊拉克或阿富汗战场，但他却所领受的任务是他从未想像过的：为他牺牲的战友们安排葬礼。怀孕妻子站在遗体旁。', '1005', '142-673x977.jpg', '1');
INSERT INTO `picture` VALUES ('1026', null, null, '图为《旧金山纪事报》记者迪恩·费茨莫里斯拍摄的一幅照片，她用自己敏感的镜头语言，描述了美国奥克兰市一家医院治疗一个在爆炸事件中身受重伤的伊拉克儿童。看到黑白照片上男孩把笔绑在因爆炸而致残的胳膊上画画，包括普利策评委在内的很多人都为之动容。', '1005', '153-673x386.jpg', '3');
INSERT INTO `picture` VALUES ('1027', null, null, '这是美联社记者拍摄的一名美军士兵在伊拉克纳杰夫用假动作吸引狙击手的照片。这幅照片获得2005年度普利策突发新闻摄影奖。', '1005', '162-673x1016.jpg', '3');
INSERT INTO `picture` VALUES ('1028', null, null, '摄影师卡罗琳·科尔由于在利比里亚的出色工作获得2004年度普利策奖特写摄影奖。在这张卡罗琳拍摄的照片中，一名利比里亚政府军士兵奋力保卫一座桥梁。', '1005', '172-673x439.jpg', '1');
INSERT INTO `picture` VALUES ('1029', null, null, '在这张卡罗琳拍摄的照片中，利比里亚首都蒙罗维亚政府军与反政府武装激战后的街道弹壳遍地。', '1005', '182-673x961.jpg', '2');
INSERT INTO `picture` VALUES ('1030', null, null, '唐·巴特莱利（Don Bartletti）拍摄了一组关于中美洲年青人北上美国的移民历程的照片。由于其不顾自身危险的敬业精神和极具价值的新闻照片，唐·巴特莱利被授予2003年普利策专题摄影新闻奖。图为一名洪都拉斯男孩坐在开往墨西哥的火车上，每年有上千来自中美洲的年青人偷渡到北美洲。', '1005', '192-673x454.jpg', '4');
INSERT INTO `picture` VALUES ('1031', null, null, '图为在墨西哥的偷渡者监狱中一群来自危地马拉的十几岁小孩准备被送返。', '1005', '202-673x388.jpg', '1');
INSERT INTO `picture` VALUES ('1032', null, null, '2017年11月2日，一名在缅甸逃离暴力的罗兴亚难民向路过的人求助。', '1005', '20180417_111556_020.jpg', '1');
INSERT INTO `picture` VALUES ('1033', null, null, '2017年12月10日，在巴扎尔附近的Kutupalong难民营，罗辛亚难民营的孩子们在放风筝。', '1005', '20180417_111556_011.jpg', '1');
INSERT INTO `picture` VALUES ('1034', null, null, '当地时间2015年9月18日，塞尔维亚Tovarnik火车站，难民竭力挤进前往克罗地亚萨格勒布的火车。', '1005', '1461235186837597.jpg', '1');
INSERT INTO `picture` VALUES ('1035', null, null, '2015年11月7日，无数难民穿过的救生衣扔在希腊莱斯博斯岛。', '1005', '1461235229922953.jpg', '1');
INSERT INTO `picture` VALUES ('1036', null, null, '2015年9月1日，布达佩斯凯莱蒂火车站，大批来自叙利亚的难民支着帐篷住在这里。', '1005', '1461235272143140.jpg', '1');
INSERT INTO `picture` VALUES ('1037', null, null, '2015年11月6日，难民乘船抵达斯科拉，船上坐了150人。', '1005', '1461235341385165.jpg', '1');
INSERT INTO `picture` VALUES ('1038', null, null, '2015年9月5日，匈牙利布达佩斯，一位来自叙利亚的父亲（中）和儿子以及其他家庭成员睡在一辆从布达佩斯开往维也纳的大巴的地板上。', '1005', '1461235368778605.jpg', '0');
INSERT INTO `picture` VALUES ('1039', null, null, '2015年9月16日，匈牙利和塞尔维亚交界地区，警察向试图越境进入塞尔维亚的难民释放了催泪瓦斯、辣椒喷雾和水炮，一名男子试图救下他的孩子。', '1005', '1461235466696143.jpg', '0');
INSERT INTO `picture` VALUES ('1040', null, null, '2015年11月28日，马其顿士兵在希腊这一侧的边境建起围栏，拦住了至少2500名难民。', '1005', '1461235583864730.jpg', '0');
INSERT INTO `picture` VALUES ('1041', null, null, '2015年8月15日，希腊科斯岛，在乘坐一艘轻薄的橡皮艇安全抵达科斯岛以后，伊拉克人Laith Majid抱着他的儿子和女儿喜极而泣。', '1005', '1461235684432274.jpg', '1');
INSERT INTO `picture` VALUES ('1042', null, null, '2015年9月24日，希腊莱斯博斯岛，一名叙利亚难民抱着孩子从一艘小船上下来。', '1005', '1461235893774788.jpg', '0');
INSERT INTO `picture` VALUES ('1043', null, null, '百老汇音乐剧《哈密尔顿》', '1005', '1461293656680087.jpg', '0');
INSERT INTO `picture` VALUES ('1044', null, null, '2011年2月19日下午，融水苗族自治县安陲乡苗族群众自发组织“十七坡会”，一名男子与数千人在斗马现场激情观看斗马赛时，被一匹奔马撞倒在地。就在马蹄即将踏上他身体的瞬间，这匹通人性的马儿不顾后有“追兵”，张嘴迅速咬住男子的衣服，将他放在一旁。随后，它和后面的一匹马相继从男子身上跃过，男子毫发无损。记者抓拍到了奔马救人的镜头。', '1005', 'e7658645_135e1d21d9dg215.jpg', '0');
INSERT INTO `picture` VALUES ('1045', null, null, '2011年11月10晚上，广西壮族自治区来宾市金秀瑶族自治县金秀镇孟村瑶寨的茶山瑶，在瑶寨举行“盘王节”，当晚，瑶族人民表演光踩下火海。', '1005', 'e7658645_135e1cdc08fg213.jpg', '0');
INSERT INTO `picture` VALUES ('1046', null, null, '《铁路边的商店》—— 阿拉巴州的一座铁路边的普通商店，再现了美国30年代乡村富有的一面！', '1002', 'ceedEaVvGrX6.jpg', '0');
INSERT INTO `picture` VALUES ('1047', null, null, '1975年英联邦橄榄球决赛上，包括英女皇伊丽莎白在内聚集在看台上，这个体形优美的裸跑者澳大利亚会计师米歇尔.奥.布瑞恩跑过球场来到看台前，这尴尬的场面让女王差点晕倒！', '1002', 'ceczOyryAuQnU.jpg', '1');
INSERT INTO `picture` VALUES ('1048', null, null, '《撤退》——这是在撤退中的美国的海军士兵，邓肯别具匠心，真切的表现了当时极度的寒冷，1950年美国海军陆战队在朝鲜作战，冬季来临之前战况一直不错。当时麦克阿瑟将军的部队高估了自己的实力，以为他们会顺利推进到朝鲜北部，他们都意想不到地受到中国援朝军队的回击。史密斯将军的话使他们的失利更加出名：“撤退？他母亲的（此乃程子文邹邹的翻译，英文原文为shit）！我们打错了方向...”', '1002', 'ceqxnO2D7yfuM.jpg', '0');
INSERT INTO `picture` VALUES ('1049', null, null, '《温斯顿．丘吉尔》——1941年1月27日，刚开完会的丘吉尔来到唐宁街10号的一个小隔间拍摄几张表现坚毅刚强的照片。然而，抽着雪茄的丘吉尔显得过于轻松，跟优素福-卡什所设想的领导神韵不符，于是卡什走上前去，把雪茄从这位领袖的嘴里拿开，丘吉尔吃了一惊，他被卡什的举动激怒了。就在他怒视卡什的一剎那，卡什按下了快门。这张照片在世界广为流传，成为丘吉尔照片中最著名的一张。', '1002', 'ceuWaZclyTvfs.jpg', '1');
INSERT INTO `picture` VALUES ('1050', null, null, '《旋转的温达》这张照片是杜瓦诺1953年在一条大街上拍的。这期间，他拍摄大量温达的照片。温达在她父母的马戏团工作，实际上她是一个脱衣舞表演者，被称作“激情的蜗牛”。对“温达”的着迷来源于她的表演所带来的强烈对比：表演场里黑乎乎的，条件极其简陋，连街头苦力都可以进去看她的表演。外面则十分明亮。这明确地显示了公共场所和隐秘场所的对比。', '1005', 'ceFNRQPA5WegY.jpg', '0');
